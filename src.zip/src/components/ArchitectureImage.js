import React from 'react';

const ArchitectureImage = () => {
  return (
    <div className="architecture-image">
      <img src="./../../public/bg-cai-fang-unsplash.jpg" alt="Architectural Representation" />
    </div>
  );
};

export default ArchitectureImage;